const imagenesCarrusel = ['img/wallpapers-para-celular-do-pokemon-6.webp',
    'img/wallpapers-para-celular-do-pokemon-17.webp',
    'img/wallpapers-para-celular-do-pokemon-21.webp',
    'img/wallpapers-para-celular-do-pokemon-23.webp'
];

let indiceActual = 0;
const imgTag = document.getElementById('imagenCarrusel');
imgTag.src = imagenesCarrusel[indiceActual];

function cambiarImagen(direccion) {
    indiceActual = (indiceActual + direccion +imagenesCarrusel.length) % imagenesCarrusel.length;
    imgTag.src = imagenesCarrusel[indiceActual]
}
setInterval(() => {
    cambiarImagen(1);
}, 3000);