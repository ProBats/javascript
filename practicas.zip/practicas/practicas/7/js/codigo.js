function mostrarMensaje(numeroImagen){
    alert('Hiciste clic en una imagen'+ numeroImagen);
}

function mostrarModal(src) {
    const modal = document.getElementById('modal');
    const imagenModal = document.getElementById('imagenModal');
    imagenModal.src = src;
    modal.style.display = 'flex';
}
function cerrarModal() {
    const modal = document.getElementById('modal');
    modal.style.display = 'none';
}