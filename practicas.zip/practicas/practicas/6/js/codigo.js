function mostrarMensaje(){
    alert('Hiciste clic en una imagen');
}