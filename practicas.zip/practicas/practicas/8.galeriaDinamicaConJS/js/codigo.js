const imagenes = ['img/wallpapers-para-celular-do-pokemon-6.webp',
    'img/wallpapers-para-celular-do-pokemon-17.webp',
    'img/wallpapers-para-celular-do-pokemon-21.webp',
    'img/wallpapers-para-celular-do-pokemon-23.webp'
];

const contenedor = document.getElementById('galeria');

imagenes.forEach((url, index) =>{
    const img = document.createElement('img');
    img.src = url;
    img.alt ='Imagen' + (index + 1);
    img.onclick=() => mostrarModal(url);
    contenedor.appendChild(img);
});