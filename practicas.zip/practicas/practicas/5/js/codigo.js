const formulario = document.getElementById("formulario-contacto");

formulario.addEventListener("submit", function (e){
    const nombre = document.getElementById('nombre');
    const email = document.getElementById('email');
    const mensaje = document.getElementById('mensaje');

    if (nombre.value.trim().length < 2) {
        alert('Por favor ingrese un nombre  valido');
        nombre.focus();
        e.preventDefault();
        return;
    }

    if (!email.value.includes('@') || email.value.trim() < 5) {
        alert('Por favor ingresa un correo valido');
        email.focus();
        e.preventDefault();
        return;
    }

    if(mensaje.value.trim().length < 10){
        alert('El mensaje debe tener al menos 10 caracteres');
        mensaje.focus();
        e.preventDefault();
        return;
    }

    alert('Gracias! Tu mensaje fue  enviado correctamente')
    
})